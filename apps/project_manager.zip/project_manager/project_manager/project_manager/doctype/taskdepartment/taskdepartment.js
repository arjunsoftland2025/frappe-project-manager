// Copyright (c) 2025, softland and contributors
// For license information, please see license.txt

// frappe.ui.form.on("TaskDepartment", {
// 	refresh(frm) {

// 	},
// });
